from dotenv import load_dotenv
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import PydanticOutputParser
from langchain_anthropic import ChatAnthropic
from pydantic import BaseModel
import os

load_dotenv()
apiKey = os.getenv("CLAUDE_API_KEY")
# class ResearchPaperAssistant(BaseModel):
#     topic: str
#     summary: str

# parser=PydanticOutputParser(pydantic_object=ResearchPaperAssistant)
# prompt = ChatPromptTemplate.from_messages([
#     (
#         "system",
#         """
#         You are a research assistant that will help generate a research paper.
#         Answer the user query and use neccessary tools. 
#         Wrap the output in this format and provide no other text\n{format_instructions}
#         """,
#     ),
#     ("placeholder", "{chat_history}"),
#     ("human", "{query}"),
#     ("placeholder", "{agent_scratchpad}"),
# ]).partial(format_instructions=parser.get_format_instructions())

llm = ChatAnthropic(model="claude-haiku-4-5-20251001",api_key=apiKey)
respone = llm.invoke("What is national bird of India?")
print(respone)