# agent.py
import os
import json
import time
from typing import Any, Callable, Dict, List, Optional
from pydantic import BaseModel
import openai
import wikipedia
from dotenv import load_dotenv

load_dotenv()
# openai.api_key = os.getenv("OPENAI_API_KEY")  # set your key
client = openai.OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

# ---- Tool system ----
class Tool(BaseModel):
    name: str
    description: str
    func: Callable[..., Any]

def wiki_search(query: str, sentences: int = 2) -> str:
    try:
        page = wikipedia.summary(query, sentences=sentences)
        return page
    except Exception as e:
        return f"Wiki error: {e}"

def add(a: float, b: float) -> float:
    return a + b

TOOLS = {
    "wiki_search": Tool(name="wiki_search", description="Search Wikipedia for a topic", func=wiki_search),
    "add": Tool(name="add", description="Add two numbers", func=add),
}

# ---- Output schema ----
class AgentResponse(BaseModel):
    final_answer: str
    tools_used: List[str]
    tool_outputs: Dict[str, Any]

# ---- LLM call wrapper ----
def call_llm(messages: List[Dict], max_tokens=512) -> Dict:
    # using OpenAI chat completion (replace if using any other provider)
    resp = client.chat.completions.create(
        model="gpt-4o-mini",  # replace with available model
        messages=messages,
        max_tokens=max_tokens,
        temperature=0.2,
    )
    return resp.choices[0].message.content

# ---- Simple planner that asks LLM what tool to use next ----
def planner_loop(user_query: str, max_iterations: int = 3) -> AgentResponse:
    system_prompt = (
        "You are an agent that can call tools. "
        "When you want to call a tool, respond with a JSON object: "
        '{"action": "call_tool", "tool": "<tool_name>", "args": {...}} '
        "When you want to finish, respond with: {'action': 'finish', 'answer': '<final answer>'} "
        "Only emit valid JSON on its own line."
    )

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_query},
    ]

    tools_used = []
    tool_outputs = {}

    for i in range(max_iterations):
        llm_msg = call_llm(messages)
        content = llm_msg.strip()

        # Try to parse JSON from LLM
        try:
            j = json.loads(content)
        except Exception:
            # If not JSON, ask LLM to comply
            messages.append({"role":"assistant","content":content})
            messages.append({"role":"user","content":"Please respond only with the described JSON format."})
            continue

        action = j.get("action")
        if action == "call_tool":
            tool_name = j.get("tool")
            args = j.get("args", {})
            tool = TOOLS.get(tool_name)
            if not tool:
                # unknown tool: tell LLM and continue
                messages.append({"role":"assistant","content":json.dumps({"error":"unknown_tool","tool":tool_name})})
                continue
            # Execute tool
            try:
                result = tool.func(**args)
            except Exception as e:
                result = f"Tool execution error: {e}"
            # Log and expose to LLM
            tools_used.append(tool_name)
            tool_outputs[tool_name] = result
            messages.append({"role":"assistant","content":json.dumps({"tool_result": {tool_name: result}})})
            # loop continues
        elif action == "finish":
            answer = j.get("answer", "")
            return AgentResponse(final_answer=answer, tools_used=tools_used, tool_outputs=tool_outputs)
        else:
            # unknown action: ask for clarification
            messages.append({"role":"assistant","content":json.dumps({"error":"unknown_action","received":j})})

    # fallback if max_iterations reached — synthesize
    final_text = "I could not complete the requested steps within iteration limit."
    return AgentResponse(final_answer=final_text, tools_used=tools_used, tool_outputs=tool_outputs)

# ---- CLI entrypoint ----
if __name__ == "__main__":
    q = input("What can I help you with? ")
    resp = planner_loop(q, max_iterations=4)
    print("Final Answer:", resp.final_answer)
    print("Tools used:", resp.tools_used)
    print("Tool outputs:", resp.tool_outputs)
